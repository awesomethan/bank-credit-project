# Credit_Card_Approval_ML
Checking to see if a certain individual will be approved for a credit card or not based on their information.
